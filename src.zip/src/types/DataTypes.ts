export interface Internship {
  internshipId: number;
  position: string;
  description: string;
  requirement: string;
  benefits: string;
  salary: number;
  companyId: number;
  majorId: number;
}

export interface Company {
  companyId: number;
  companyName: string;
  phoneNumber: string;
  websiteUrl: string;
  address: string;
  location: string;
  accountId: number;
}

export interface Major {
  majorId: number;
  majorName: string;
}
