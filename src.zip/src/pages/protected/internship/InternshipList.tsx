import React, { useEffect, useState } from "react";
import { Internship, Company, Major } from "../../../types/DataTypes";
import { Button } from "react-bootstrap";
import { fetchInternships } from "../../../services/InternshipServices";
import { fetchCompanies } from "../../../services/CompanyServices";
import { fetchMajors } from "../../../services/MajorServices";

// Dữ liệu mẫu
const companies: Company[] = [
  {
    companyId: 1,
    companyName: "Tech Corp",
    phoneNumber: "123-456-7890",
    websiteUrl: "http://techcorp.com",
    address: "123 Tech Street",
    location: "Hanoi",
    accountId: 101,
  },
  {
    companyId: 2,
    companyName: "Design Studio",
    phoneNumber: "987-654-3210",
    websiteUrl: "http://designstudio.com",
    address: "456 Creative Ave",
    location: "Ho Chi Minh City",
    accountId: 102,
  },
];

const majors: Major[] = [
  {
    majorId: 1,
    majorName: "Computer Science",
  },
  {
    majorId: 2,
    majorName: "Graphic Design",
  },
];

const internships: Internship[] = [
  {
    internshipId: 1,
    position: "Frontend Developer Intern",
    description: "Work on web development projects using React.",
    requirement: "Basic knowledge of HTML, CSS, and JavaScript.",
    benefits: "Gain hands-on experience and mentorship.",
    salary: 500,
    companyId: 1,
    majorId: 1,
  },
  {
    internshipId: 2,
    position: "Graphic Designer Intern",
    description: "Assist in designing marketing materials.",
    requirement: "Proficiency in Adobe Illustrator and Photoshop.",
    benefits: "Learn creative design skills and work on real projects.",
    salary: 300,
    companyId: 2,
    majorId: 2,
  },
];

const InternshipList: React.FC = () => {

  const [internshipData, setInternshipData] = useState<Internship[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [majors, setMajors] = useState<Major[]>([]);

  const fetchAllData = async () => {
    const internships = await fetchInternships();
    const companiesData = await fetchCompanies();
    const majorsData = await fetchMajors();
    
    setInternshipData(internships);
    setCompanies(companiesData);
    setMajors(majorsData);
  };

  useEffect(() => {
    fetchAllData();
  }, []);
  return (
    <div className="row">
      <div className="col-lg-12 grid-margin stretch-card">
        <div className="card">
          <div className="card-body">
            <h4 className="card-title">Internship List</h4>
            <div className="table-responsive pt-3">
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Position</th>
                    <th>Major</th>
                    <th>Company</th>
                    <th>Requirement</th>
                    <th>Salary</th>
                    <th>Benefits</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {internshipData.map((internship, index) => {
                    const company = companies.find(
                      (c) => c.companyId === internship.companyId
                    );
                    const major = majors.find(
                      (m) => m.majorId === internship.majorId
                    );

                    return (
                      <tr key={internship.internshipId}>
                        <td>{index + 1}</td>
                        <td>{internship.position}</td>
                        <td>{major ? major.majorName : "N/A"}</td>
                        <td>{company ? company.companyName : "N/A"}</td>
                        <td>{internship.requirement}</td>
                        <td>{internship.salary}</td>
                        <td>{internship.benefits}</td>
                        <td>{internship.description}</td>
                        <td>
                          <Button
                            type="button"
                            className="btn btn-inverse-info btn-icon"
                            style={{marginRight: '0.5rem'}}
                          >
                            <i className="ti-pencil-alt"></i>
                          </Button>

                          <button
                            type="button"
                            className="btn btn-inverse-danger btn-icon"
                          >
                            <i className="ti-trash"></i>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            
            </div>
            <div style={{display: 'flex', 
              justifyContent: 'end',}}>
            <div className="btn-group" 
            role="group" 
            aria-label="Basic example"
            style={{marginTop: '1rem'}}>
                          <button type="button" className="btn btn-outline-secondary">1</button>
                          <button type="button" className="btn btn-outline-secondary">2</button>
                          <button type="button" className="btn btn-outline-secondary">3</button>
                        </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InternshipList;
