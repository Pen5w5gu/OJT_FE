// File: src/services/AuthService.ts
import { jwtDecode } from "jwt-decode";
import axiosInstance from "./Axios";
interface JwtPayload {
  nameid: string;  // ID của user
  name: string;    // Tên user
  email: string;   // Email user
  role: string;    // Vai trò user
  exp: number;     // Thời gian hết hạn token (UNIX timestamp)
}

const AuthService = {
  getToken: (): string | null => {
    return localStorage.getItem("accessToken");
  },

  setToken: (accessToken: string) => {
    localStorage.setItem("accessToken", accessToken);
  },

  removeToken: () => {
    localStorage.removeItem("accessToken");
  },

  decodeToken: (): JwtPayload | null => {
    const token = AuthService.getToken();
    if (!token) return null;
    try {
      return jwtDecode<JwtPayload>(token);
    } catch (error) {
      console.error("Invalid token", error);
      return null;
    }
  },

  getUserInfo: () => {
    const decoded = AuthService.decodeToken();
    if (!decoded) return null;
    return {
      id: decoded.nameid,
      name: decoded.name,
      email: decoded.email,
      role: decoded.role,
    };
  },

  isTokenExpired: (): boolean => {
    const decoded = AuthService.decodeToken();
    if (!decoded) return true;
    return decoded.exp * 1000 < Date.now();
  },

  login: async (email: string, password: string) => {
    const response = await axiosInstance.post("api/Auth/signin", { email, password });
    if (response.data.accessToken) {
      AuthService.setToken(response.data.accessToken);
    }
    return response.data;
  },

  isAuthenticated: (): boolean => {
    return !!AuthService.getToken();
  }
};

export default AuthService;
