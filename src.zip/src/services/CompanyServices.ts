import { Company } from "../types/DataTypes";
import axiosInstance from "./Axios";
import axios from "axios";
// URL của API backend
const API_URL = "http://localhost:5128/api/Company";

// Hàm lấy tất cả công ty
export const fetchCompanies = async (): Promise<Company[]> => {
  try {
    const response = await axios.get(`${API_URL}/get-all-companies`);
    return response.data;
  } catch (error) {
    console.error("Error fetching companies:", error);
    return [];
  }
};
