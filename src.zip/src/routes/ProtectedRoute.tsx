// File: ProtectedRoute.tsx
import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import AuthService from "../services/AuthService";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const location = useLocation();
  const user = AuthService.getUserInfo();
  console.log('user: ', user);
  
  // if (!user) {
  //   return <Navigate to="/login" state={{ from: location }} replace />;
  // }

  // if (!allowedRoles.includes(user.role)) {
  //   return <Navigate to="/403-forbidden" replace />;
  // }

  return <>{children}</>;
};

export default ProtectedRoute;
